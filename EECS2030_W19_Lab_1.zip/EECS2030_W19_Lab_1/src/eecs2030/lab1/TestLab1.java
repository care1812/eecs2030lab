package eecs2030.lab1;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestLab1 {

	private static Random rng = new Random();

	@Test//Ques.1
	public void test01_minInt() {
		assertEquals(Integer.MIN_VALUE, Lab01.minInt());
	}

	@Test //Ques.1
	public void test02_maxDouble() {
		assertEquals(0, Double.compare(Double.MAX_VALUE, Lab01.maxDouble()));
	}

 @Test//Ques. 2
 public void test03_removeLastTwoDigits() {
   final int[] EXPECTED = {1, 5, 9, 27, 345, 7821};
   for (Integer exp : EXPECTED) {
     for (int i = 0; i < 100; i++) {
       int n = i + 100 * exp;
       String error = String.format("Lab01.removeLastTwoDigits(%d) failed", n);
       assertEquals(error, exp.intValue(), Lab01.removeLastTwoDigits(n));
     }
   }
   assertEquals("Lab01.removeLastTwoDigits(2147483647) failed",
       21474836, Lab01.removeLastTwoDigits(Integer.MAX_VALUE));
 }


	
 @Test //Ques. 2
 public void test04_lastOneDigit() {
   final int[] FIRST_DIGITS = {1, 5, 9, 27, 345, 7821};
   for (Integer d : FIRST_DIGITS) {
     for (int exp = 0; exp < 10; exp++) {
       int n = 10 * d + exp;
       String error = String.format("Lab01.lastOneDigit(%d) failed", n);
       assertEquals(error, exp, Lab01.lastOneDigit(n));
     }
   }
   assertEquals("Lab01.lastOneDigit(2147483647) failed", 7, Lab01.lastOneDigit(Integer.MAX_VALUE));
 }


	 
 @Test //Ques.2
 public void test05_yourAge() {
   rng.setSeed(5);
   for (int birthYear = 2016; birthYear > 1917; birthYear--) {
     int address = rng.nextInt(10000);
     int exp = 2017 - birthYear - 1;
     String error = String.format("Lab01.yourAge(%d, %d, %d) failed",
         address, birthYear, 0);
     assertEquals(error, exp, Lab01.yourAge(address, birthYear, 0));
     
     error = String.format("Lab01.yourAge(%d, %d, %d) failed",
         address, birthYear, 1);
     assertEquals(error, exp + 1, Lab01.yourAge(address, birthYear, 1));
   }
 }
    
    
	

	@Test //Ques. 3
	public void test06_rayleigh() {
		final double[] x = { -10.0, -5.0, -3.0, -1.0, 0, 1.0, 3.0, 5.0, 10.0 };
		final double[] exp = { 9.31663293019668e-07,    -0.0549,   -0.2435,   -0.2206,         0,    0.2206,    0.2435,    0.0549, 9.31663293019668e-07 };
		int sigma=2;
		for (int i = 0; i < x.length; i++) {
			String error = String.format("normal(%s) failed\n", x[i]);
			assertEquals(error, exp[i], Lab01.rayleigh(x[i], sigma), 1e-1);
	}
	}

	
	//Ques. 4
	@Test(expected = IllegalArgumentException.class)
	public void test07() {
		String s = "a";
		String t = "ab";
		Lab01.distance(s, t);
	}
	
	@Test
	public void test08() {
		String s = "a";
		String t = "a";
		int exp = 0;
		assertEquals("distance(\"a\", \"a\") failed\n", exp, Lab01.distance(s, t));
	}
	
	@Test
	public void test09() {
		String s = "z";
		String t = "a";
		int exp = 1;
		assertEquals("distance(\"z\", \"a\") failed\n", exp, Lab01.distance(s, t));
	}
	
	@Test
	public void test10() {
		String s = "summer";
		String t = "summed";
		int exp = 1;
		assertEquals("distance(\"summer\", \"summed\") failed\n", exp, Lab01.distance(s, t));
	}
	
	@Test
	public void test11() {
		String s = "summer";
		String t = "bummer";
		int exp = 1;
		assertEquals("distance(\"summer\", \"bummer\") failed\n", exp, Lab01.distance(s, t));
	}
	
	
	
	@Test
	public void test12() {
		String s = "summer";
		String t = "though";
		int exp = 6;
		assertEquals("distance(\"summer\", \"though\") failed\n", exp, Lab01.distance(s, t));
	}
	
	

	//Ques. 5

	  @Test
	  public void test13_isInsideCircle() {
	    rng.setSeed(9);
	    // random points inside the unit circle
	    for (int i = 0; i < 100; i++) {
	      double radius = rng.nextDouble();  // less than 1
	      double radians = 2.0 * Math.PI * i / 100;
	      double x = radius * Math.cos(radians);
	      double y = radius * Math.sin(radians);
	      String error =
	          String.format("Lab01.isInside(%f, %f) failed (returned false)", x, y);
	      assertTrue(error, Lab01.isInside(x, y));
	    }
	    // random points outside the unit circle
	    for (int i = 0; i < 100; i++) {
	      double radius = 1.0 + rng.nextDouble() + Math.ulp(1.0);  // greater than 1
	      double radians = 2.0 * Math.PI * i / 100;
	      double x = radius * Math.cos(radians);
	      double y = radius * Math.sin(radians);
	      String error =
	          String.format("Lab01.isInside(%f, %f) failed (returned true)", x, y);
	      assertFalse(error, Lab01.isInside(x, y));
	    }
	    // some points exactly on the unit circle
	    final double[] X = {1.0, 0.0, -1.0,  0.0};
	    final double[] Y = {0.0, 1.0,  0.0, -1.0};
	    for (int i = 0; i < X.length; i++) {
	      double x = X[i];
	      double y = Y[i];
	      String error =
	          String.format("Lab01.isInside(%f, %f) failed (returned true)", x, y);
	      assertFalse(error, Lab01.isInside(x, y));
	    }
	  }


	@Test//Ques. 6
	public void test14_isLeapYear() {
		final int[] notLeapYr = { 1582, 1700, 1800, 1900, 2001 };
		final int[] isLeapYr = { 1592, 1600, 1904, 2000, 2016 };

		for (int yr : isLeapYr) {
			String error = String.format("isLeapYear(%s) failed (returned false)", yr);
			assertTrue(error, Lab01.isLeapYear(yr));
		}

		for (int yr : notLeapYr) {
			String error = String.format("isLeapYear(%s) failed (returned true)", yr);
			assertFalse(error, Lab01.isLeapYear(yr));
		}
	}

	@Test//Ques. 6
	public void test15_isLeapYear() {
		try {
			Lab01.isLeapYear(1581);
			fail("isLeapYear(1581) should have thrown an exception");
		} catch (IllegalArgumentException x) {
			// ok
		} catch (Exception ex) {
			fail("isLeapYear threw the wrong type of exception");
		}
	}

	@Test //Ques. 7
	public void test16_contains() {
		rng.setSeed(13);
		for (int i = 0; i < 100; i++) {
			int min = rng.nextInt(100) - 50;
			int max = min + i;
			this.testOutsideRange(min, max);
			this.testInsideRange(min, max);
		}
	}

	private void testOutsideRange(int min, int max) {
		final double[] X = { Double.NEGATIVE_INFINITY, min - 100.0, min - 1.0, Math.nextAfter(min, min - 1.0), min, max,
				Math.nextAfter(max, max + 1.0), max + 1.0, max + 100.0, Double.POSITIVE_INFINITY };
		Range r = new Range(min, max);
		for (double x : X) {
			String error = String.format("contains(%s, r) failed\n" + "where r = %s\n", x, r);
			assertEquals(error, 0, Lab01.contains(x, r));
		}
	}
	
	

	private void testInsideRange(int min, int max) {
		if (min == max) {
			return;
		}
		double xStart = Math.nextAfter(min, min + 1.0);
		double xEnd = Math.nextAfter(max, max - 1.0);
		double step = (xEnd - xStart) / 10;
		double[] X = new double[10];
		X[0] = xStart;
		X[9] = xEnd;
		for (int i = 1; i < 9; i++) {
			X[i] = X[i - 1] + step;
		}
		Range r = new Range(min, max);
		for (double x : X) {
			String error = String.format("contains(%s, r) failed\n" + "where r = %s\n", x, r);
			assertEquals(error, 1, Lab01.contains(x, r));
		}
	}
	
	

	@Test //Ques. 8
	public void test17_compareTo() {
		rng.setSeed(14);
		for (int i = 0; i < 100; i++) {
			int min = rng.nextInt(100) - 50;
			Range skinny = new Range(min, min + 1);
			min = rng.nextInt(100) - 50;
			Range skinny2 = new Range(min, min + 1);
			min = rng.nextInt(100) - 50;
			Range wide = new Range(min, min + 2);
			String error = String.format("compareTo(r1, r2) failed for r1 = %s, r2 = %s", skinny, skinny);
			assertEquals(error, 0, Lab01.compareTo(skinny, skinny));

			error = String.format("compareTo(r1, r2) failed for r1 = %s, r2 = %s", skinny, skinny2);
			assertEquals(error, 0, Lab01.compareTo(skinny, skinny2));

			error = String.format("compareTo(r1, r2) failed for r1 = %s, r2 = %s", skinny, wide);
			assertEquals(error, -1, Lab01.compareTo(skinny, wide));

			error = String.format("compareTo(r1, r2) failed for r1 = %s, r2 = %s", wide, skinny);
			assertEquals(error, 1, Lab01.compareTo(wide, skinny));
		}
	}

	
	
	
	@Test //Ques. 9
	public void test18_toString() {
		String exp = "minimum: -10.00000001, maximum: 9253.353156731684";
		Range r = new Range(-10.00000001, 9253.353156731684);
		String error = String.format("toString(r) failed for r = %s", r.toString());
		assertEquals(error, exp, Lab01.toString(r));
	}

	private static char randChar() {
		return (char) ('A' + rng.nextInt(26));
	}
	
	@Test //Ques. 10
	public void test16_charFromEnd() {
		StringBuilder s = new StringBuilder();
		StringBuilder t = new StringBuilder();
		for (int i = 0; i < 10; i++) {
			char c = TestLab1.randChar();
			s.append(c);
			t.insert(0, c);
		}
		String str = s.toString();
		for (int i = 0; i < 10; i++) {
			char exp = t.charAt(i);
			char got = Lab01.charFromEnd(str, i);
			String error = String.format("charFromEnd(%s, %s) failed\nexpected: %c but was: %c", 
					str, i, exp, got);
			assertTrue(error, exp == got);
		}
	}
	
//////////////////////////////////////////////////////////////////
	@Test //Ques. 11
	public void test19_sort3() {
		ArrayList<Integer> t = new ArrayList<>();
		String error = "sort2(t) failed to throw an IllegalArgumentException";
		try {
			Lab01.sort2(t);
			fail(error);
		} catch (IllegalArgumentException x) {
			// do nothing
		} catch (Exception x) {
			fail("sort2(t) threw the wrong kind of exception");
		}

		t.add(1);
		try {
			Lab01.sort2(t);
			fail(error);
		} catch (IllegalArgumentException x) {
			// do nothing
		} catch (Exception x) {
			fail("sort2(t) threw the wrong kind of exception" + x);
		}

		t.add(2);
		try {
			Lab01.sort2(t);
			fail(error);
		} catch (IllegalArgumentException x) {
			// do nothing
		} catch (Exception x) {
			fail("sort2(t) threw the wrong kind of exception" + x);
		}
		
		t.add(3);
		t.add(4);
		try {
			Lab01.sort2(t);
			fail(error);
		} catch (IllegalArgumentException x) {
			// do nothing
		} catch (Exception x) {
			fail("sort2(t) threw the wrong kind of exception");
		}
	}

	@Test //Ques. 11
	public void test20_sort3() {
		ArrayList<Integer> t = new ArrayList<>();
		t.add(1000);
		t.add(0);
		t.add(-1000);

		ArrayList<Integer> u = new ArrayList<>(t);
		String error = String.format("sort2(t) failed for t = %s", u.toString());
		Lab01.sort2(u);
		
		 
		assertEquals(error, t, u);
		

		u.clear();
		u.add(t.get(2));
		u.add(t.get(1));
		u.add(t.get(0));
		error = String.format("sort2(t) failed for t = %s", u.toString());
		Lab01.sort2(u);
		assertEquals(error, t, u);

	}
	////////////////////////////////////////////////////////////////

	@Test //Ques 12
	public void test21_frequency() {
		List<String> t = new ArrayList<>();
		String target = "hi";
		String error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 0, Lab01.frequency(t, target));
	}

	@Test //Ques 12
	public void test22_frequency() {
		List<String> t = Arrays.asList("hi");
		String target = "hi";
		String error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 1, Lab01.frequency(t, target));
		
		target = "bye";
		error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 0, Lab01.frequency(t, target));
	}
	
	@Test //Ques 12
	public void test23_frequency() {
		List<String> t = Arrays.asList("hi", "bye", "bye", "hi", "bye", "bye", "fly");
		String target = "hi";
		String error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 2, Lab01.frequency(t, target));
		
		target = "bye";
		error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 4, Lab01.frequency(t, target));
		
		target = "fly";
		error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 1, Lab01.frequency(t, target));
		
		target = "cry";
		error = String.format("frequency(%s, %s) failed\n", 
				t.toString(), target);
		assertEquals(error, 0, Lab01.frequency(t, target));
	}
	///////////////////////////////////////////////////////////////////
	
	@Test //Ques 13
	public void test24a_repair() {
		List<Integer> t = new ArrayList<>();
		Lab01.repair(t);
		assertTrue("repair([]) failed",
				t.isEmpty());
	}
	
	@Test //Ques 13
	public void test24b_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(3));
		List<Integer> exp = new ArrayList<>(t);
		Lab01.repair(t);
		assertEquals("repair([3]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24c_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(3, 4));
		List<Integer> exp = new ArrayList<>(t);
		Lab01.repair(t);
		assertEquals("repair([3, 4]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24d_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(4, 3));
		List<Integer> exp = new ArrayList<>(Arrays.asList(3, 4));
		Lab01.repair(t);
		assertEquals("repair([4, 3]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24e_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(0, 2, 1));
		List<Integer> exp = new ArrayList<>(Arrays.asList(0, 1, 2));
		Lab01.repair(t);
		assertEquals("repair([0, 2, 1]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24f_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(0, 2, 1, 3));
		List<Integer> exp = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
		Lab01.repair(t);
		assertEquals("repair([0, 2, 1, 3]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24g_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(0, 2, 1, 4, 3));
		List<Integer> exp = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4));
		Lab01.repair(t);
		assertEquals("repair([0, 2, 1, 4, 3]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24h_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(0, 1, 3, 2, 4));
		List<Integer> exp = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4));
		Lab01.repair(t);
		assertEquals("repair([0, 1, 3, 2, 4]) failed",
				exp, t);
	}
	
	@Test //Ques 13
	public void test24i_repair() {
		List<Integer> t = new ArrayList<>(Arrays.asList(0, 5, 10, 9, 20, 22, 37, 150, 99, 200));
		List<Integer> exp = new ArrayList<>(Arrays.asList(0, 5, 9, 10, 20, 22, 37, 99, 150, 200));
		Lab01.repair(t);
		assertEquals("repair([0, 1, 3, 2, 4]) failed",
				exp, t);
	}
	
	
	/////////////////////////////////////////////////////
	  @Test //Ques 14
	  public void test25_q14() 
	  {
		  List<Character> aList = Arrays.asList('h', 'o', 'r', 's', 'e', '.');
	      aList = Lab01.shuffle(aList);
	      List<Character> bList = Arrays.asList('h', 's', 'o', 'e', 'r', '.');
	      assertEquals(bList, aList);
	  }
	 
	  @Test //Ques 15
	  public void test26_toRadians() {
	    rng.setSeed(20);
	    ArrayList<Double> deg = new ArrayList<>();
	    ArrayList<Double> degCopy = new ArrayList<>();
	    ArrayList<Double> rad = new ArrayList<>();
	    
	    String error = 
	        String.format("Lab01.toRadians(t) failed for t = %s", deg.toString());
	    Lab01.toRadians(degCopy);
	    assertEquals(error, rad, degCopy);

	    for (int i = 0; i < 100; i++) {
	      double angDeg = rng.nextInt(2880) - 1440;
	      double angRad = Math.toRadians(angDeg);
	      deg.add(angDeg);
	      degCopy = (ArrayList<Double>) deg.clone();
	      rad.add(angRad);
	      error = 
	          String.format("Lab01.toRadians(t) failed for t = %s", deg.toString());
	      Lab01.toRadians(degCopy);
	      assertEquals(error, rad, degCopy);
	    }
	  }
	  
	  
	  
}
